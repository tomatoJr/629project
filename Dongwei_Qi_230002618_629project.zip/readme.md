# @Date    : 2019-11-26 22:04:07
# @Author  : Dong (dongwei@tamu.edu)
# @Link    : https://github.com/tomatoJr
# @Version : 1.0.0

Software:
Visual Studio Code 1.39.2
Language:
Python 3.7.4 64-bit
System:
macOS Mojave 10.14.6
Processor:
1.4 GHz Intel Core i5
Memory:
8 GB 2133 MHz LPDDR3
Graphics:
Intel Iris Plus Graphics 645 1536 MB


Ready to use:
1.Before run the code, use pip to download according libs include random, math, collections, time.

2.Get into MainFuntion.py which is the main entrance of the project, and execute it.
